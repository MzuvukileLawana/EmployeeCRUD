﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Extenals
{
    public static class EmployeeExtensions
    {
        public static void Map(this Employee dbEmployee, Employee employeer)
        {
            dbEmployee.FullName = employeer.FullName;
            dbEmployee.Position = employeer.Position;
            dbEmployee.Level = employeer.Level;
            dbEmployee.DateEngaged = employeer.DateEngaged;
        }
    }
}
