﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Entities.Models
{
    [Table("employee")]
    public class Employee
    {
        [Key]
        public int EmpID { get; set; }

        [Required(ErrorMessage = "Full Name is required")]
        [StringLength(60, ErrorMessage = "Full Name can't be longer than 60 characters")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Position is required")]
        [StringLength(60, ErrorMessage = "Position can't be longer than 60 characters")]
        public string Position { get; set; }

        [Required(ErrorMessage = "Level is required")]
        [StringLength(60, ErrorMessage = "Level can't be longer than 60 characters")]
        public string Level { get; set; }


        [Required(ErrorMessage = "Date of birth is required")]
        public DateTime DateEngaged { get; set; }
    }
}
