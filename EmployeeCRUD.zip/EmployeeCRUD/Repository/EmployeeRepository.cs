﻿using Contracts;
using Entities;
using Entities.Extenals;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Repository
{
    public class EmployeeRepository : RepositoryBase<Employee>, IEmployeeRepository
    {
        public EmployeeRepository(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {
        }

        public IEnumerable<Employee> GetAllEmployees()
        {
            return FindAll()
                .OrderBy(ow => ow.FullName);
        }
        public Employee GetEmployeeById(int empId)
        {
            return FindByCondition(employee => employee.EmpID.Equals(empId))
                    .FirstOrDefault();
        }
        public void CreateEmployee(Employee employee)
        {
            employee.EmpID = new Int16();
            Create(employee);
            Save();
        }
        public void UpdateEmployee(Employee dbEmployee, Employee employee)
        {
            dbEmployee.Map(employee);
            Update(dbEmployee);
            Save();
        }
        public void DeleteEmployee(Employee employee)
        {
            Delete(employee);
            Save();
        }


    }
}
